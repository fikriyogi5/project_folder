<?php
require('user.php'); // Impor kelas User

$user = new User();
$users = $user->getUsers();

foreach ($users as $userData) {
    echo "Nama: " . $userData['nama'] . "<br>";
}
