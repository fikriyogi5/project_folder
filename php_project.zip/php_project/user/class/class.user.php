<? php
require('koneksi.php'); // Impor file koneksi

class User
{
    protected $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function getUsers()
    {
        // Lakukan pengambilan data dari tabel pengguna
        $query = "SELECT * FROM users";
        $stmt = $this->db->connection->query($query);

        // Ambil data sebagai array asosiatif
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $users;
    }
}
