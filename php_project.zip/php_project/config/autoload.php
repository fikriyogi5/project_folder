<?php
spl_autoload_register(function ($class) {
    // Mengonversi namespace ke path file
    $classPath = str_replace('\\', DIRECTORY_SEPARATOR, $class);
    $filePath = __DIR__ . '/class/' . $classPath . '.php';

    if (file_exists($filePath)) {
        require_once $filePath;
    }
});
