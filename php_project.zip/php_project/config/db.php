<?php
class Database
{
    private $host = "localhost";
    private $username = "username";
    private $password = "password";
    private $database = "nama_database";
    private $charset = "utf8mb4";

    protected $connection;

    public function __construct()
    {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->database};charset={$this->charset}";
            $this->connection = new PDO($dsn, $this->username, $this->password);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
        }
    }
}
